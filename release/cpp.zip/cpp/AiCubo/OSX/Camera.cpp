//
//  Camera.cpp
//  RMXKit
//
//  Created by Max Bilbow on 30/07/2015.
//  Copyright © 2015 Rattle Media Ltd. All rights reserved.
//
#import <iostream>
#import <GLKit/GLKVector3.h>
//#import <GLKit/GLKVector4.h>
#import <GLKit/GLKMatrix4.h>
#import "Object.h"
#import "ASingleton.h"
#import "Camera.h"

