//
//  Tools.h
//  RMXKit
//
//  Created by Max Bilbow on 30/07/2015.
//  Copyright © 2015 Rattle Media Ltd. All rights reserved.
//

#ifndef Tools_h
#define Tools_h

#include <stdio.h>

#endif /* Tools_h */


namespace RMX {
    class Tools {
    public:
        static float * RandomColor();
    };
    
}