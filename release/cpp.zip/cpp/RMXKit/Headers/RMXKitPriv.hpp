/*
 *  RMXKitPriv.hpp
 *  RMXKit
 *
 *  Created by Max Bilbow on 28/07/2015.
 *  Copyright © 2015 Rattle Media Ltd. All rights reserved.
 *
 */

#include <CoreFoundation/CoreFoundation.h>

#pragma GCC visibility push(hidden)
class CRMXKit {
    public:
        CFStringRef UUID(void);
};

#pragma GCC visibility pop

