//
//  Behaviour.cpp
//  RMXKit
//
//  Created by Max Bilbow on 31/07/2015.
//  Copyright © 2015 Rattle Media Ltd. All rights reserved.
//

#include "Behaviour.h"
#define as_string(x) #x
using namespace rmx;
using namespace std;




void RMXBehaviourTest() {
    Behaviour * b = new Behaviour();
    Object::Destroy(b);
}

